
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    
    private static final String URL = "jdbc:mysql://localhost/ffgym";
    private static final String USER = "root";
    private static final String PASS = "";
    private static Connection conexion = null;
    
    //Metodo para conectar a la base de datos
    public static Connection conectarBD(){
        try {
            return conexion = DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            System.err.println("Error en la conexion a la base de datos: " + e.getMessage());
            return null;
        }
    }
    
    //Metodo para cerrar la conexion a la base de datos una vez terminada la consulta
    public static void cerrarConexion(){
        if(conexion != null){
            try {
                conexion.close();
                conexion = null;
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexion" + e.getMessage());
            }
        }
    }
}
