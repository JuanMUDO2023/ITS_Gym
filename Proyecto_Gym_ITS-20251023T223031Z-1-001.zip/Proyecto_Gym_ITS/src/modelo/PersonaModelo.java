
package modelo;

import java.util.ArrayList;

public class PersonaModelo {
    private String nombre;
    private String apellido;
    private DireccionModelo direccion;
    private String numeroDePuerta;
    private ArrayList<String> telefono;
    private String email;

    public PersonaModelo(String nombre, String apellido, DireccionModelo direccion, String numeroDePuerta, ArrayList<String> telefono, String email) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.numeroDePuerta = numeroDePuerta;
        this.telefono = new ArrayList<>();
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public DireccionModelo getDireccion() {
        return direccion;
    }

    public void setDireccion(DireccionModelo direccion) {
        this.direccion = direccion;
    }

    public String getNumeroDePuerta() {
        return numeroDePuerta;
    }

    public void setNumeroDePuerta(String numeroDePuerta) {
        this.numeroDePuerta = numeroDePuerta;
    }

    public ArrayList<String> getTelefono() {
        return telefono;
    }

    public void setTelefono(ArrayList<String> telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
}
