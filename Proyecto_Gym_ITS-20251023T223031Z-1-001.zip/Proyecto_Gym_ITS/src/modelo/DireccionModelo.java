
package modelo;


public class DireccionModelo {
    private String calle;
    private String numeroDePuerta;

    public DireccionModelo(String calle, String numeroDePuerta) {
        this.calle = calle;
        this.numeroDePuerta = numeroDePuerta;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getNumeroDePuerta() {
        return numeroDePuerta;
    }

    public void setNumeroDePuerta(String numeroDePuerta) {
        this.numeroDePuerta = numeroDePuerta;
    }
    
    
}
