
package modelo;

import controlador.AdministradorControlador;
import static modelo.ValidarDatosPersonales.validarCedula;
import vista.AdministradorVista;


public class AdministradorModelo {
    
    
    private AdministradorVista vista;
    private AdministradorControlador controlador;
    
    private void asistenciaSocio (String cedula){
        cedula = vista.getTxtCedula().getText();
        
        if (validarCedula(cedula)){
            //Consulta a la BD cedula
        }
    }
}
