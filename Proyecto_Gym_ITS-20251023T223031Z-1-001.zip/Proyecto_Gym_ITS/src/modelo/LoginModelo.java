
package modelo;


public class LoginModelo {
    
    private final String usuarioValido = "admin";
    private final String passwordValido = "1234";
    
    public boolean autenticar(String usuario, String password){
        return usuario.equals(usuarioValido) && password.equals(passwordValido);
    }

    public String getUsuarioValido() {
        return usuarioValido;
    }

}
