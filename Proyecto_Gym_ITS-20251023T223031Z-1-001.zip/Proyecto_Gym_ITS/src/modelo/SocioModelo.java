
package modelo;

import java.util.ArrayList;

public class SocioModelo extends PersonaModelo{
    
    private int edad;
    
    private enum TipoDeSocio {
        ADULTO,
        LICEAL,
        ESCOLAR,
        PREESCOLAR
    }

    public SocioModelo(int edad, String nombre, String apellido, DireccionModelo direccion, String numeroDePuerta, ArrayList<String> telefono, String email) {
        super(nombre, apellido, direccion, numeroDePuerta, telefono, email);
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    
    
    
    
    
}
