
package modelo;

/**
 *
 * @author Juan_Admin
 */
public class ValidarDatosPersonales {
    
    //Metodo para validar el telefono celular o fijo 
    public static boolean esTelefonoValido(String telefono) {
        telefono = telefono.replaceAll("[\\s\\-]", "").trim();

        if (telefono.matches("^09\\d{7}$")) {
            return true;
        } // Celular
        if (telefono.matches("^[24567]\\d{7}$")) {
            return true;
        } // Fijo

        return false;
    }

    private static final String EMAIL_REGEX = 
            "^[A-Za-z0-9+_.-]+@[A-za-z0-9.-]+\\.[A-Za-z]{2,}$";
    
    //Metodo para validar el email 
    public static boolean esEmailValido(String email){
        if (email == null){
            return false;
        }
        return email.matches(EMAIL_REGEX);
    }
    
    public static boolean validarCedula(String cedula){
        return cedula != null && cedula.matches("\\d{8}");
    }
    
    public static boolean validarNumeroPuerta (String numero){
        if (numero == null || numero.isBlank()){
            return false;
        }
        return numero.matches("\\d+");
    }
}
