
package controlador;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import modelo.LoginModelo;
import vista.AdministradorVista;
import vista.LoginVista;

public class LoginControlador {
    
    private LoginModelo modelo;
    private LoginVista vista;
    
    
    //Agregar metodo de control de campos
    //Agregar metodo de mostrarContraseña
    //Agregar metodo de validar login (llama al modelo)

    public LoginControlador(LoginModelo modelo, LoginVista vista) {
        this.modelo = modelo;
        this.vista = vista;
        
        iniciarEventos();
    }
    
    private void iniciarEventos(){
        vista.getBtnIngresar().addActionListener(e -> validarLogin());
        vista.getjCheckBoxMostrarPassword().addActionListener(e -> mostrarPassword());
        vista.getTxtPassword().addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e){
                vista.getTxtPassword().setText("");
            }
        });
        vista.getTxtPassword().addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e){
                verificarCampos();
            }
        });
        
        vista.getTxtNomUsuario().addActionListener(e -> validarLogin());
        vista.getTxtNomUsuario().addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased (KeyEvent e){
                verificarCampos();
            }
        });
    }
    
    /**
     * Metodo que verifica en principio, que los campos usuario y contraseña
     * hayan sido escritos, no comprueba validez de los datos.
     * Si los campos fueron completados, se habilita el boton INGRESAR
     */
    private void verificarCampos(){
        String usuario = vista.getTxtNomUsuario().getText();
        String pass = String.valueOf((vista.getTxtPassword().getPassword()));
        boolean habilitar = !usuario.isEmpty() && !pass.isEmpty();
        vista.getBtnIngresar().setEnabled(habilitar);
    }
    
    /**
     * Metodo para accionar el checkbox de mostrar contraseña
     */
    private void mostrarPassword(){
        if (vista.getjCheckBoxMostrarPassword().isSelected()){
            vista.getTxtPassword().setEchoChar((char) 0);
        } else {
            vista.getTxtPassword().setEchoChar('*');
        }
    }
    
    /**
     * Metodo para validar los datos ingresados, los que se comprueban desde
       el modelo verificando en la base de datos
     */
    private void validarLogin(){
        String usuario = vista.getTxtNomUsuario().getText();
        String pass = String.valueOf(vista.getTxtPassword().getPassword());
        
        if (modelo.autenticar(usuario, pass)){
            JOptionPane.showMessageDialog(vista, "Acceso correcto");
            AdministradorVista administrador = new AdministradorVista();
            administrador.setVisible(true);
            vista.dispose(); //Cerramos ventana login cuando se abre la vista administrador
        } else {
            JOptionPane.showMessageDialog(vista, "Usuario o contraseña incorrecta");
        }
    }
    
}
