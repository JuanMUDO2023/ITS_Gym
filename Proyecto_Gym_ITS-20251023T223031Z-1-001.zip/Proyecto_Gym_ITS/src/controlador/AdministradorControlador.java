
package controlador;


import vista.AdministradorVista;
import vista.NuevoSocioVista;


public class AdministradorControlador {
    
    
    private AdministradorVista vista;
    

    public AdministradorControlador(AdministradorVista vista) {
        this.vista = vista;
        inicializarEvento();
    }
    
    private void inicializarEvento (){
        vista.getJmenuNuevoSocio().addActionListener(e -> abrirNuevoSocio());
    }
    
    private void abrirNuevoSocio (){
        NuevoSocioVista nuevoSocio = new NuevoSocioVista();
        nuevoSocio.setVisible(true);
        vista.dispose();
    }
}
