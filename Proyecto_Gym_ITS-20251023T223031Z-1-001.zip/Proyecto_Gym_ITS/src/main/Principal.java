package main;

import controlador.LoginControlador;
import modelo.LoginModelo;
import vista.LoginVista;

public class Principal {

    public static void main(String[] args) {
        LoginVista vista = new LoginVista();
        LoginModelo modelo = new LoginModelo();
        LoginControlador controlador = new LoginControlador(modelo, vista);
        vista.setVisible(true);
    }

}
